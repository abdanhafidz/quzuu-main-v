<?php
// © 2021 www.adanz.com - AdanZ Framework By Abdan Hafidz .
// Created With Love By Abdan Hafidz
// +-- Kontrolisasi Penambahan Library/Files --+
// Please Donate Me https://abdanhafidz.com/donate

//inklud files yang ingin anda gabungkan di sini
session_start();

//[[[[[[ INKLUD FILE BERIKUT ADALAH DEFAULT DIMOHON UNTUK TIDAK DIRUBAH ]]]]]]



include 'config/__dbconnection.php';
include 'fondasi/function/PHP/main.php';
include 'config/__main.inc.php';



//[[[[[[ INKLUD FILE BERIKUT ADALAH DEFAULT DIMOHON UNTUK TIDAK DIRUBAH ]]]]]]



?>