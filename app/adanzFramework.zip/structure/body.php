
          <?php
          if(modul==''){
            include 'modul/dashboard.php';
          }elseif(modul=='sinkronisasi'){
              include 'modul/sinkronisasi.php';
          }elseif(modul=='peserta' AND act==''){
              include 'modul/peserta.php';
          }elseif(modul=='peserta' AND act=='show'){
            include 'modul/show-peserta.php';
        }elseif(modul=='peserta' AND act=='edit'){
            include 'modul/edit-peserta.php';
        }elseif(modul=='editgroup'){
            include 'modul/edit-group.php';
        }elseif(modul=='ujian' AND act==''){
            include 'modul/ujian.php';
        }elseif(modul=='ujian' AND act=='edit'){
            include 'modul/edit-ujian.php';
        }elseif(modul=='ujian' AND act=='Soal'){
            include 'modul/soal.php';
        }elseif(modul=='ujian' AND act=='editsoal'){
            include 'modul/edit-soal.php';
        }elseif(modul=='picksibankso' AND act=='aktif'){
            include 'modul/pick-sibankso.php';
        }elseif(modul=='picksibankso' AND act=='tidakaktif'){
            include 'modul/error-sibankso.php';
        }elseif(modul=='picksibankso' AND act=='pilih'){
            include 'modul/pilih-sibankso.php';
        }elseif(modul=='result' AND act==''){
            include 'modul/hasil_ujian.php';
        }elseif(modul=='result' AND act=='show'){
            include 'modul/show_hasil_ujian.php';
        }elseif(modul=='result' AND act=='mark'){
            include 'modul/mark.php';
        }elseif(modul=='result' AND act=='edit'){
            include 'modul/edit-mark.php';
        }elseif(modul=='ujian' AND act=='grouping'){
            include 'modul/grouping_ujian.php';
        }elseif(modul=='users' AND act==''){
            include 'modul/users.php';
        }elseif(modul=='users' AND act=='editusers'){
            include 'modul/edit-users.php';
        }elseif(modul=='users' AND act=='editproktor'){
            include 'modul/edit-proktor.php';
        }elseif(modul=='logout'){
            session_destroy();
            echo '<script>window.location="'.domain.'/login"</script>';
        }
          ?>
