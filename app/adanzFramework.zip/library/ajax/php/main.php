<?php
session_start();
include '../../../config/__dbconnection.php';
include '../../../fondasi/function/PHP/main.php';
include '../../../config/__main.inc.php';

// © 2021 www.adanz.com - AdanZ Framework By Abdan Hafidz .
// Created With Love By Abdan Hafidz
// +-- Ajax Rest --+
// Please Donate Me https://abdanhafidz.com/donate

///Contoh : if(@$_GET['action']=='Aksi Ajax'){
       //ekspresi aksi CRUD dari data ajax yang diterima
///}