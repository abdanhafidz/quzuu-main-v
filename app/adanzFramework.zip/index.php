<?php
include 'controller/main.php';

?>
<?php


        ?>
<html>
    <head>
        <?php 
        include 'structure/head.php';
        ?>
        </head>
        <body>

<?php 
        include 'structure/body.php';
        ?>
    

<?php 
        include 'structure/footer.php';
        ?>

</body>
</html>
<?php

?>